package com.adobe.aem.illinois.core.servlets;

import java.io.IOException;
import java.util.Iterator;
import java.util.LinkedList;
import java.util.List;

import javax.servlet.Servlet;

import org.apache.commons.lang3.StringUtils;
import org.apache.sling.api.SlingHttpServletRequest;
import org.apache.sling.api.SlingHttpServletResponse;
import org.apache.sling.api.request.RequestParameter;
import org.apache.sling.api.resource.Resource;
import org.apache.sling.api.resource.ResourceResolver;
import org.apache.sling.api.resource.ValueMap;
import org.osgi.service.component.annotations.Component;
import org.osgi.service.component.annotations.Reference;

import com.adobe.aem.illinois.core.constants.SOIConstants;
import com.adobe.cq.wcm.core.components.models.contentfragment.ContentFragmentList;
import com.adobe.granite.ui.components.Config;
import com.adobe.granite.ui.components.ExpressionResolver;
import com.adobe.granite.ui.components.ds.DataSource;
import com.adobe.granite.ui.components.ds.EmptyDataSource;
import com.adobe.granite.ui.components.ds.SimpleDataSource;
import com.day.cq.commons.jcr.JcrConstants;

@Component(
        service = {Servlet.class},
        property = {
                "sling.servlet.resourceTypes=" + ContentFragmentListTagsDataSource.RESOURCE_TYPE_V1,
                "sling.servlet.resourceTypes=" + ContentFragmentListTagsDataSource.RESOURCE_TYPE_ORDER_BY_V1_TAGS,
                "sling.servlet.resourceTypes=" + ContentFragmentListTagsDataSource.RESOURCE_TYPE_DYNAMIC_PAGE_PATH_V1,
                "sling.servlet.methods=GET",
                "sling.servlet.extensions=html"
        }
)
public class ContentFragmentListTagsDataSource extends AbstractDataSourceServlet {
	/**
	 * Serial version UID
	 */
	private static final long serialVersionUID = 1L;
	
	/**
	 * Resource tpye for content fragment field element
	 */
	public static final String RESOURCE_TYPE_V1 = "soi/contentfragmentlist/v1/datasource/elements";
	
	/**
	 * Resource type for order by field
	 */
    public static final String RESOURCE_TYPE_ORDER_BY_V1_TAGS = "soi/contentfragmentlist/v1/datasource/orderbytags";

    /**
     * Resource tpye for dynamic page path
     */
    public static final String RESOURCE_TYPE_DYNAMIC_PAGE_PATH_V1 = "soi/contentfragmentlist/v1/datasource/elements/linkitems";
    
    /**
     * Content Fragment model path
     */
    protected static final String PARAMETER_AND_PN_MODEL_PATH = ContentFragmentList.PN_MODEL_PATH;

    /**
     * ExpressionResolver
     */
    @Reference
    private transient ExpressionResolver expressionResolver;

    /**
     * Get expression resolver
     * 
     * @return ExpressionResolver
     */
    @Override
    protected ExpressionResolver getExpressionResolver() {
        return expressionResolver;
    }

    /**
     * Do get.
     *
     * @param request
     *            {@link SlingHttpServletRequest}
     * @param response
     *            {@link SlingHttpServletResponse}
     * @throws IOException
     */
    @Override
    protected void doGet(SlingHttpServletRequest request, SlingHttpServletResponse response) {

        RequestParameter modelPathRequestParameter = request.getRequestParameter(PARAMETER_AND_PN_MODEL_PATH);
        boolean isOrderBy = request.getResource().isResourceType(RESOURCE_TYPE_ORDER_BY_V1_TAGS);

        boolean isDynamicPagePath = request.getResource().isResourceType(RESOURCE_TYPE_DYNAMIC_PAGE_PATH_V1);

        String modelPath = getModelPath(request, modelPathRequestParameter);

        DataSource dataSource = EmptyDataSource.instance();

        if (modelPath != null) {
            ResourceResolver resourceResolver = request.getResourceResolver();

            String pathToCFModelElements = String.format("%s/%s/model/cq:dialog/content/items",
                    modelPath, JcrConstants.JCR_CONTENT);
            Resource cfModelElementRoot = resourceResolver.getResource(pathToCFModelElements);
            if (cfModelElementRoot != null) {            	
            	List<Resource> resourceList = getResourceList(request, isOrderBy, cfModelElementRoot, resourceResolver,isDynamicPagePath);
                dataSource = new SimpleDataSource(resourceList.iterator());
            }
        }

        request.setAttribute(DataSource.class.getName(), dataSource);
    }

    /**
     * Get resource list
     * 
     * @param request
     * @param isOrderBy
     * @param cfModelElementRoot
     * @param resourceResolver
     * @return list of resource
     */
	private List<Resource> getResourceList(SlingHttpServletRequest request, boolean isOrderBy, 
			Resource cfModelElementRoot, ResourceResolver resourceResolver, boolean isDynamicPagePath) {
		Iterator<Resource> resourceIterator = cfModelElementRoot.listChildren();
        List<Resource> resourceList = new LinkedList<>();

        while (resourceIterator.hasNext()) {
            Resource elementResource = resourceIterator.next();
            ValueMap valueMap = elementResource.getValueMap();
            String valueValue = valueMap.get("name", "");
            String textValue = valueMap.get("fieldLabel", valueValue);
            if (isOrderBy && StringUtils.isNotEmpty(valueValue)) {
                valueValue = "jcr:content/data/master/" + valueValue;
            }
            String metaType = valueMap.get("metaType", StringUtils.EMPTY);
            if (!isOrderBy || StringUtils.startsWith(metaType, "tag")) {
                Resource syntheticResource = createResource(resourceResolver, textValue, valueValue);
                resourceList.add(syntheticResource);
            }
        }
        if (isDynamicPagePath) {
            Resource syntheticResource = createResource(resourceResolver, SOIConstants.DYNAMIC_PAGE_LINK_KEY, SOIConstants.DYNAMIC_PAGE_LINK);
            resourceList.add(syntheticResource);
        }
		return resourceList;
	}

	/**
	 * Get model path
	 * 
	 * @param request
	 * @param modelPathRequestParameter
	 * @return String
	 */
	private String getModelPath(SlingHttpServletRequest request, RequestParameter modelPathRequestParameter) {
		String modelPath;
        if (modelPathRequestParameter != null) {
            modelPath = modelPathRequestParameter.getString();
        } else {
            Config config = getConfig(request);
            ValueMap componentValueMap = getComponentValueMap(config, request);

            // get model path from component resource
            modelPath = (!componentValueMap.isEmpty()) ?
                    componentValueMap.get(ContentFragmentList.PN_MODEL_PATH, String.class) : null;
        }
		
        return modelPath;
	}
}
