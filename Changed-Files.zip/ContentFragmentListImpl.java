package com.adobe.aem.illinois.core.models.impl;

import static com.day.cq.dam.api.DamConstants.NT_DAM_ASSET;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.HashMap;
import java.util.Iterator;
import java.util.LinkedHashMap;
import java.util.LinkedList;
import java.util.List;
import java.util.Map;
import java.util.regex.Pattern;

import javax.annotation.PostConstruct;
import javax.jcr.Session;

import org.apache.commons.lang3.StringUtils;
import org.apache.sling.api.SlingHttpServletRequest;
import org.apache.sling.api.resource.Resource;
import org.apache.sling.api.resource.ResourceResolver;
import org.apache.sling.models.annotations.Default;
import org.apache.sling.models.annotations.DefaultInjectionStrategy;
import org.apache.sling.models.annotations.Exporter;
import org.apache.sling.models.annotations.Model;
import org.apache.sling.models.annotations.injectorspecific.ChildResource;
import org.apache.sling.models.annotations.injectorspecific.Self;
import org.apache.sling.models.annotations.injectorspecific.SlingObject;
import org.apache.sling.models.annotations.injectorspecific.ValueMapValue;

import com.adobe.aem.illinois.core.constants.SOIConstants;
import com.adobe.aem.illinois.core.models.ContentFragmentList;
import com.adobe.aem.illinois.core.models.ElementModel;
import com.adobe.aem.illinois.core.utils.SOICommonsUtils;
import com.adobe.aem.illinois.core.utils.URLUtils;
import com.adobe.cq.dam.cfm.ContentElement;
import com.adobe.cq.dam.cfm.ContentFragment;
import com.adobe.cq.export.json.ComponentExporter;
import com.adobe.cq.export.json.ExporterConstants;
import com.day.cq.commons.jcr.JcrConstants;
import com.day.cq.dam.api.Asset;
import com.day.cq.dam.api.DamConstants;
import com.day.cq.search.Predicate;
import com.day.cq.search.PredicateGroup;
import com.day.cq.search.Query;
import com.day.cq.search.QueryBuilder;
import com.day.cq.search.result.SearchResult;
import com.day.cq.tagging.Tag;
import com.day.cq.tagging.TagConstants;
import com.day.cq.tagging.TagManager;

/**
 * ContentFragmentList component model class
 */
@Model(adaptables = { SlingHttpServletRequest.class }, adapters = { ContentFragmentList.class,
		ComponentExporter.class, }, resourceType = ContentFragmentListImpl.RESOURCE_TYPE, defaultInjectionStrategy = DefaultInjectionStrategy.OPTIONAL)
@Exporter(name = ExporterConstants.SLING_MODEL_EXPORTER_NAME, extensions = ExporterConstants.SLING_MODEL_EXTENSION)
public class ContentFragmentListImpl extends CommonFieldsImpl implements ContentFragmentList {
	/**
	 * Resource type
	 */
	public static final String RESOURCE_TYPE = "soi/components/fragments/v1/contentfragmentlist";

	/**
	 * Default max items 
	 */
	public static final int DEFAULT_MAX_ITEMS = -1;

	/**
	 * Request
	 */
	@Self
	private SlingHttpServletRequest request;

	/**
	 * Request resolver
	 */
	@SlingObject
	private ResourceResolver resourceResolver;

	/**
	 * Defines the parent path
	 */
	@ValueMapValue
	private String parentPath;

	/**
	 * Define the tag names
	 */
	@ValueMapValue
	private String[] tagNames;

	/**
	 * Defines the and/or tag match
	 */
	@ValueMapValue
	private String tagsMatch;

	/**
	 * Defines the content fragment model path
	 */
	@ValueMapValue
	private String modelPath;


	/**
	 * Defines the content fragment dynamic page path
	 */
	@ValueMapValue
	private String dynamicPageLink;

	/**
	 * Display header if true
	 */
	@ValueMapValue
	private boolean displayHeader;

	/**
	 * Enable sorting option if true
	 */
	@ValueMapValue
	@Default(booleanValues = false)
	private boolean displaySort;

	/**
	 * Enable search option if true
	 */
	@ValueMapValue
	@Default(booleanValues = false)
	private boolean displaySearch;

	/**
	 * Enable column options if true
	 */
	@ValueMapValue
	@Default(booleanValues = false)
	private boolean columnsEnabled;

	/**
	 * Defined group by items
	 */
	@ValueMapValue
	private String groupBy;

	/**
	 * Defines header element
	 */
	@ValueMapValue
	private String headerElement;
	
	@ValueMapValue
	private String headerElementTag;

	@ValueMapValue
	private String headerElementDate;

	/**
	 * Defines header style
	 */
	@ValueMapValue
	private String headerStyle;
	
	/**
	 * Defines header sort By
	 */
	@ValueMapValue
	private String headerSortOrder;

	/**
	 * Define number of columns to display
	 */
	@ValueMapValue
	private String columns;

	/**
	 * Defines number of items in row before pagination
	 */
	@ValueMapValue
	private Integer paginateRow;

	/**
	 * Defines content direction
	 */
	@ValueMapValue
	private String contentDirection;

	/**
	 * Define number of items before pagination for desktop
	 */
	@ValueMapValue
	private Integer paginateDesktop;

	/**
	 * Define number of items before pagination for mobile
	 */
	@ValueMapValue
	private Integer paginateMobile;

	/**
	 * Max items to display in desktop
	 */
	@ValueMapValue
	private Integer maxItemsDesktop;

	/**
	 * Max items to display in mobile
	 */
	@ValueMapValue
	private Integer maxItemsMobile;

	/**
	 * Define filter items
	 */
	@ValueMapValue
	private String filterElements;

	/**
	 * Child items of content fragment
	 */
	@ChildResource
	private List<ElementModel> elements;

	/**
	 * Enable fragment link
	 */
	@ValueMapValue
	@Default(booleanValues = false)
	private boolean linkFragment;

	/**
	 * Defines element name
	 */
	@ValueMapValue
	private String linkElementName;

	/**
	 * Defines link target
	 */
	@ValueMapValue
	@Default(booleanValues = false)
	private boolean linkTarget;

	/**
	 * Defines link email
	 */
	@ValueMapValue
	@Default(booleanValues = false)
	private boolean linkEmail;

	/**
	 * Defines link phone number
	 */
	@ValueMapValue
	@Default(booleanValues = false)
	private boolean linkPhoneNumber;

	/**
	 * Defines order by to query items
	 */
	@ValueMapValue
	@Default(values = JcrConstants.JCR_CREATED)
	private String orderBy;

	/**
	 * Defines sort order to the query items
	 */
	@ValueMapValue
	@Default(values = Predicate.SORT_ASCENDING)
	private String sortOrder;

	/**
	 * Defines item back ground color
	 */
	@ValueMapValue
	private String listItemBackGroundColor;
	
	/**
	 * Element title that is not authored
	 */
	private Map<String,String> unauthoredElementTitles;

	/**
	 * Define element map
	 */
	private Map<String, ElementModel> elementNamesMap = new LinkedHashMap<>();

	/**
	 * Define fragment list items
	 */
	private List<Map<String, Object>> fragmentList = new ArrayList<>();

	private List<String> unauthoredElementNames;

	@PostConstruct
	public void init() {
		if (elements != null) {
			createElementsNameMap(elements);
		}

		if (parentPath != null && modelPath != null) {
			unauthoredElementNames = new ArrayList<>();
			unauthoredElementNames.add(StringUtils.substringAfterLast(orderBy, SOIConstants.FW_SLASH));
			if (groupBy.equals("alphabetical")) {
				unauthoredElementNames.add(StringUtils.substringAfterLast(headerElement, SOIConstants.FW_SLASH));
			} else if (groupBy.equals("tag")) {
				unauthoredElementNames.add(StringUtils.substringAfterLast(headerElementTag, SOIConstants.FW_SLASH));
			} else if (groupBy.equals("date")) {
				unauthoredElementNames.add(StringUtils.substringAfterLast(headerElementDate, SOIConstants.FW_SLASH));
			}
			buildContentFragmentItems();
			// add the not authored element to the element map
			if (!unauthoredElementNames.isEmpty()) {
				for (String unauthoredElement : unauthoredElementNames) {
					if (!elementNamesMap.keySet().contains(unauthoredElement)) {
						ElementModel eleModel = new ElementModel();
						eleModel.setElementAuthored(Boolean.FALSE);
						eleModel.setElementName(unauthoredElement);
						eleModel.setLabelStyle(SOIConstants.HIDDEN);
						eleModel.setValueStyle(SOIConstants.HIDDEN);
						eleModel.setElementTitle(unauthoredElementTitles != null ? unauthoredElementTitles.get(unauthoredElement) : StringUtils.EMPTY);
						elementNamesMap.put(unauthoredElement, eleModel);
					}
				}
			}
		}		
	}

	/**
	 * Method to create element configuration map
	 * 
	 * @param List<ElementModel> - list of element option
	 */
	private void createElementsNameMap(List<ElementModel> elementsList) {
		for (ElementModel model : elementsList) {
			elementNamesMap.put(model.getElementName(), model);
		}		
	}	

	/**
	 * Method to search the content fragment from dam and build 
	 * the item list
	 */
	private void buildContentFragmentItems() {
		Session session = resourceResolver.adaptTo(Session.class);
		QueryBuilder queryBuilder = request.getResourceResolver().adaptTo(QueryBuilder.class);
		Map<String, String> queryParameterMap = buildQueryParameter();	

		PredicateGroup predicateGroup = PredicateGroup.create(queryParameterMap);
		Query query = queryBuilder.createQuery(predicateGroup, session);
		SearchResult searchResult = query.getResult();

		ResourceResolver leakingResourceResolver = null;
		try {
			// Iterate over the hits
			Iterator<Resource> resourceIterator = searchResult.getResources();
			while (resourceIterator.hasNext()) {
				Resource resource = resourceIterator.next();				
				if (leakingResourceResolver == null) {
					// Get a reference to QB's leaking resource resolver
					leakingResourceResolver = resource.getResourceResolver();
				}
				// Adapt to ContentFragment
				ContentFragment damContentFragment = resource.adaptTo(ContentFragment.class);
				if (damContentFragment != null) {
					buildItems(damContentFragment);
				}
			}
		} finally {
			if (leakingResourceResolver != null) {
				// Always close the leaking query builder resource resolver
				leakingResourceResolver.close();
			}
		}		
	}

	/**
	 * Build the list of content fragment
	 * 
	 * @param damContentFragment
	 */
	private void buildItems(ContentFragment damContentFragment) {		
		Map<String, Object> mapElements = new LinkedHashMap<>();	
		Map<String, Object> metaMap = new LinkedHashMap<>();
		Iterator<ContentElement> contentElementIterator = filterContentFragmentElements(damContentFragment, filterElements);

		while (contentElementIterator.hasNext()) {					
			ContentElement contentElement = contentElementIterator.next();	

			if (!StringUtils.equals(contentElement.getContent(), StringUtils.EMPTY)) {				
				mapElements.put(contentElement.getName(), getContent(contentElement));
				// Add meta information
				if (elementNamesMap.containsKey(contentElement.getName())) {
					addMetaInformation(metaMap, contentElement.getName(), damContentFragment);

					addIfElementTypeIsTag(mapElements, 
							elementNamesMap.get(contentElement.getName()), contentElement);

					addIfElementTypeIsDate(mapElements, 
							elementNamesMap.get(contentElement.getName()), contentElement);					
				}
			}			
		}
		// Add the tags associated with the content fragment
		if (damContentFragment.getMetaData().containsKey(SOIConstants.DAMCONSTANT_TAG)) {
			metaMap.put(SOIConstants.TAGS, 
					getTagNames((String[]) damContentFragment.getMetaData().get(SOIConstants.DAMCONSTANT_TAG)));
		}
		// Populate if link for the content fragment is enabled
		addEntireContentFragmentLink(metaMap, damContentFragment);
		// add meta attributes
		if (!metaMap.isEmpty()) {
			mapElements.put(SOIConstants.META, metaMap);
		}
		// check for not authored element
		if (!unauthoredElementNames.isEmpty()) {
			unauthoredElementTitles = new HashMap<>();
			for (String unauthoredElementName : unauthoredElementNames) {
				if (!elementNamesMap.keySet().contains(unauthoredElementName)) {
					unauthoredElementTitles.put(unauthoredElementName, damContentFragment.getElement(unauthoredElementName) != null ?
							damContentFragment.getElement(unauthoredElementName).getTitle() : StringUtils.EMPTY);
					mapElements.put(unauthoredElementName, damContentFragment.getElement(unauthoredElementName) != null ?
							getContent(damContentFragment.getElement(unauthoredElementName)) : StringUtils.EMPTY);
				}
			}
		}

		fragmentList.add(mapElements);
	}

	/**
	 * Add the date
	 * 
	 * @param mapElements
	 * @param elementModel
	 * @param contentElement
	 */
	private void addIfElementTypeIsDate(Map<String, Object> mapElements, ElementModel elementModel,
			ContentElement contentElement) {
		if (elementModel.getElementType().equals(SOIConstants.DATE)) {				
			String date = SOICommonsUtils.parseDate(contentElement.getContent());
			if (date != null) {
				mapElements.put(contentElement.getName(), date);
			}			
		}		
	}

	/**
	 * Add multiple tags with comma separated value
	 * 
	 * @param mapElements
	 * @param elementModel
	 * @param contentElement
	 */
	private void addIfElementTypeIsTag(Map<String, Object> mapElements, ElementModel elementModel, 
			ContentElement contentElement) {
		if (elementModel.getElementType().equals(SOIConstants.TAG)) {
			Object obj = mapElements.get(contentElement.getName());
			String[] strArray; 
			// if holds multiple tags
			if (obj instanceof String[]) {
				strArray = (String[]) obj;				
			} else {
				strArray = new String[] {(String) obj};
			}

			List<String> tagList = getTagNames(strArray);
			mapElements.put(contentElement.getName(), StringUtils.join(tagList, SOIConstants.COMMA + SOIConstants.SPACE));
		}		
	}

	/**
	 * Get the content in array format
	 * 
	 * @param contentElement
	 * @return Object
	 */
	private Object getContent(ContentElement contentElement) {
		if (!checkHtmlContent(contentElement)
				&& StringUtils.contains(contentElement.getContent(), SOIConstants.NEW_LINE)) {
			return contentElement.getContent().split(SOIConstants.NEW_LINE);
		} else if (SOICommonsUtils.isValidDate(contentElement.getContent())) {
			return SOICommonsUtils.parseDate(contentElement.getContent());
		}
		
		return contentElement.getContent();
	}

	/**
	 * Checks if the content is html
	 * 
	 * @param contentElement
	 * @return boolean
	 */
	private boolean checkHtmlContent(ContentElement contentElement) {
		String html = contentElement.getContent();
		Pattern htmlPattern = Pattern.compile(".*\\<[^>]+>.*", Pattern.DOTALL);
		return htmlPattern.matcher(html).matches();
	}

	/**
	 * Get the list of tag titles or names
	 * 
	 * @param tagNames
	 * @return list
	 */
	private List<String> getTagNames(String[] tagNames) {
		List<String> tagList = new ArrayList<>();
		TagManager tagMgr = resourceResolver.adaptTo(TagManager.class);

		for (String tagStr : tagNames) {
			Tag tag = tagMgr.resolve(tagStr);			
			if (tag != null) {
				tagList.add(StringUtils.defaultIfEmpty(tag.getTitle(), tag.getName()));
			}			
		}

		return tagList;
	}

	/**
	 * Method to add the related additional information of the content fragments
	 * 
	 * @param metaMap
	 * @param name
	 * @param fragment
	 */
	private void addMetaInformation(Map<String, Object> metaMap, String name, ContentFragment fragment) {
		ElementModel model = elementNamesMap.get(name);
		model.setElementTitle(fragment.getElement(name).getTitle());

		if (model.isLinkElement() 
				&& StringUtils.isNotBlank(model.getLinkField()) && fragment.hasElement(model.getLinkField())) {
			ContentElement content = fragment.getElement(model.getLinkField());
			metaMap.put(content.getName(), buildLinkUrl(content));
		} else if(SOIConstants.DYNAMIC_PAGE_LINK.equals(model.getLinkField()) && StringUtils.isNotBlank(dynamicPageLink)){
			String formattedFragmentLink = dynamicPageLink+SOIConstants.DOT+fragment.getName()+SOIConstants.EXTENSION_HTML;
			metaMap.put(SOIConstants.DYNAMIC_PAGE_LINK, formattedFragmentLink);
		}

		if (model.getElementType().equals(SOIConstants.ASSET)) {
			addAssetInformation(metaMap, name, fragment);						
		}

		if (model.getElementType().equals(SOIConstants.IMAGE)) {
			addImageInformation(metaMap, name, fragment);	
		}
	}

	/**
	 * Method to add the image related information of the content fragments
	 * 
	 * @param metaMap
	 * @param name
	 * @param fragment
	 */
	@SuppressWarnings("unchecked")
	private void addImageInformation(Map<String, Object> metaMap, String name, ContentFragment fragment) {
		if (!checkHtmlContent(fragment.getElement(name))
				&& !StringUtils.contains(fragment.getElement(name).getContent(), SOIConstants.NEW_LINE)) {
			String imgPath = fragment.getElement(name).getContent();
			Resource imgResource = resourceResolver.getResource(imgPath);

			if (imgResource != null && imgResource.isResourceType(DamConstants.NT_DAM_ASSET)) {
				Asset asset = imgResource.adaptTo(Asset.class);

				if (!metaMap.containsKey(SOIConstants.ALT_TEXT)) {
					Map<String, String> newMap = new LinkedHashMap<>();
					newMap.put(name, 
							StringUtils.defaultIfEmpty(asset.getMetadataValue(DamConstants.DC_DESCRIPTION), StringUtils.EMPTY));
					metaMap.put(SOIConstants.ALT_TEXT, newMap);
				} else {
					Map<String, String> existingMap = (Map<String, String>) metaMap.get(SOIConstants.ALT_TEXT);
					existingMap.put(name, 
							StringUtils.defaultIfEmpty(asset.getMetadataValue(DamConstants.DC_DESCRIPTION), StringUtils.EMPTY));
				}
			}
		}		
	}

	/**
	 * Method to add the related asset information of the content fragments
	 * 
	 * @param metaMap
	 * @param name
	 * @param fragment
	 */
	@SuppressWarnings("unchecked")
	private void addAssetInformation(Map<String, Object> metaMap, String name, ContentFragment fragment) {		
		if (!checkHtmlContent(fragment.getElement(name)) 
				&& !StringUtils.contains(fragment.getElement(name).getContent(), SOIConstants.NEW_LINE)) {
			String assetPath = fragment.getElement(name).getContent();
			Resource assetResource = resourceResolver.getResource(assetPath);

			if (assetResource != null && assetResource.isResourceType(DamConstants.NT_DAM_ASSET)) {
				Asset asset = assetResource.adaptTo(Asset.class);
				Map<String, String> assetMap = new LinkedHashMap<>();

				String mimeType = StringUtils.defaultIfEmpty(asset.getMetadataValue(DamConstants.DC_FORMAT), StringUtils.EMPTY);			
				assetMap.put(SOIConstants.NAME, 
						StringUtils.defaultIfEmpty(asset.getMetadataValue(DamConstants.DC_TITLE), asset.getName()));
				assetMap.put(SOIConstants.FORMAT, 
						(mimeType.equals(StringUtils.EMPTY) ? StringUtils.EMPTY : SOICommonsUtils.getAssetMimeType(mimeType)));

				if (!metaMap.containsKey(SOIConstants.ASSET)) {
					Map<String, Map<String, String>> newMap = new LinkedHashMap<>();
					newMap.put(name, assetMap);
					metaMap.put(SOIConstants.ASSET, newMap);
				} else {
					Map<String, Map<String, String>> existingMap = 
							(Map<String, Map<String, String>>) metaMap.get(SOIConstants.ASSET);
					existingMap.put(name, assetMap);
				}
			}
		}							
	}

	/**
	 * Method to add the link for the entire content fragments
	 * 
	 * @param metaMap
	 * @param name
	 * @param fragment
	 */
	private void addEntireContentFragmentLink(Map<String, Object> metaMap, ContentFragment damContentFragment) {
		if (linkFragment 
				&& !linkElementName.isEmpty() && damContentFragment.hasElement(linkElementName)) {
			metaMap.put(linkElementName, buildLinkUrl(damContentFragment.getElement(linkElementName)));			
		}		
	}

	/**
	 * Build the link url
	 * 
	 * @param element
	 * @return String
	 */
	private String buildLinkUrl(ContentElement element) {
		if (!checkHtmlContent(element)
				&& !StringUtils.contains(element.getContent(), SOIConstants.NEW_LINE)) {
			return URLUtils.addHTMLIfPage(resourceResolver, element.getContent());
		}
		return StringUtils.EMPTY;
	}

	/**
	 * Build the query parameter
	 * 
	 * @return Map
	 */
	private Map<String, String> buildQueryParameter() {		
		Map<String, String> queryParameterMap = new LinkedHashMap<>();
		queryParameterMap.put(SOIConstants.PATH, parentPath);
		queryParameterMap.put(SOIConstants.TYPE, NT_DAM_ASSET);
		queryParameterMap.put(SOIConstants.QUERY_LIMIT_PARAM, Integer.toString(getMaxItems()));
		queryParameterMap.put(SOIConstants.QUERY_FIRST_PROP, JcrConstants.JCR_CONTENT + "/data/cq:model");
		queryParameterMap.put(SOIConstants.QUERY_FIRST_PROP_VALUE, modelPath);
		// Add order by attribute
		if (StringUtils.isNotEmpty(orderBy)) {
			queryParameterMap.put(SOIConstants.QUERY_ORDERBY_PARAM, SOIConstants.AT + orderBy);
			if (StringUtils.isNotEmpty(sortOrder)) {
				queryParameterMap.put(SOIConstants.QUERY_SORTBY, sortOrder);
			}
		}

		List<String> tagsList = buildTagList();
		// Add the tag attribute 
		if (!tagsList.isEmpty()) {
			queryParameterMap.put(SOIConstants.QUERY_SECOND_PROP, 
					JcrConstants.JCR_CONTENT + SOIConstants.QUERY_PATH_METADATA + JcrConstants.JCR_MIXINTYPES);
			queryParameterMap.put(SOIConstants.QUERY_SECOND_PROP_VALUE, TagConstants.NT_TAGGABLE);			        
			queryParameterMap.put(SOIConstants.QUERY_TAGID_PROP, SOIConstants.VD_TAG_PROPERTY);
			// Check for the actual tags (by default, tag are or'ed)
			if (tagsMatch.equals(SOIConstants.TEXT_ALL)) {
				queryParameterMap.put(SOIConstants.QUERY_TAG_ID_AND, SOIConstants.TRUE);
			}
			for (int i = 0; i < tagsList.size(); i++) {
				queryParameterMap.put(String.format(SOIConstants.QUERY_TAGID_VALUE, i + 1), tagsList.get(i));
			}
		}

		return queryParameterMap;
	}

	/**
	 * Build tag list
	 * 
	 * @return List
	 */
	private List<String> buildTagList() {
		ArrayList<String> allTags = new ArrayList<>();
		if (tagNames != null && tagNames.length > 0) {
			allTags.addAll(Arrays.asList(tagNames));
		}
		return allTags;
	}

	/**
	 * Filter content fragment items based on display element options
	 * 
	 * @param contentFragment
	 * @param elementNames
	 * @return Iterator
	 */
	private Iterator<ContentElement> filterContentFragmentElements(ContentFragment contentFragment,
			final String elementNames) {

		if (StringUtils.isNotBlank(elementNames)) {
			List<ContentElement> elementsList = new LinkedList<>();
			String[] filters = StringUtils.split(filterElements, SOIConstants.COMMA);

			for (String name : filters) {
				if (contentFragment.hasElement(name)) {
					elementsList.add(contentFragment.getElement(name));
				}				
			}
			return elementsList.iterator();
		}
		return contentFragment.getElements();
	}

	/**
	 * Get max item to search
	 * 
	 * @return int
	 */
	private int getMaxItems() {
		if (null == this.getMaxItemsDesktop() || null == this.getMaxItemsMobile()) {
			return DEFAULT_MAX_ITEMS;
		} else if (this.getMaxItemsDesktop() >= this.getMaxItemsMobile()) {
			return this.getMaxItemsDesktop();
		} else {
			return this.getMaxItemsMobile();
		}
	}

	/**
	 * Get the list items
	 * 
	 * @return List
	 */
	@Override
	public List<Map<String, Object>> getListItems() {
		return Collections.unmodifiableList(this.fragmentList);
	}

	/**
	 * Enable sorting
	 * 
	 * @return true/false
	 */
	public boolean isDisplaySort() {
		return this.displaySort;
	}

	/**
	 * Enable search
	 * 
	 * @return true/false
	 */
	public boolean isDisplaySearch() {
		return this.displaySearch;
	}

	/**
	 * Enable column display
	 * 
	 * @return true/false
	 */
	public boolean isColumnsEnabled() {
		return this.columnsEnabled;
	}

	/**
	 * Get order by field name
	 * 
	 * @return String
	 */
	public String getOrderBy() {
		return StringUtils.substringAfterLast(orderBy, SOIConstants.FW_SLASH);
	}

	/**
	 * Get sort option
	 * 
	 * @return String
	 */
	public String getSortOrder() {
		return sortOrder;
	}

	/**
	 * Get list item background color
	 * 
	 * @return String
	 */
	public String getListItemBackGroundColor() {
		return listItemBackGroundColor;
	}	

	/**
	 * Get model path of the content fragment
	 * 
	 * @return String
	 */
	public String getModelPath() {
		return this.modelPath;
	}


	/**
	 * Get dynamic page path of the content fragment
	 *
	 * @return String
	 */
	public String getDynamicPageLink() {
		return this.dynamicPageLink;
	}

	/**
	 * Get element name
	 * 
	 * @return Map
	 */
	public Map<String, ElementModel> getElementNames() {
		return this.elementNamesMap;
	}

	/**
	 * Get maximum items to display in desktop
	 * 
	 * @return Integer
	 */
	public Integer getMaxItemsDesktop() {
		return this.maxItemsDesktop;
	}

	/**
	 * Get maximum items to display in mobile
	 * 
	 * @return Integer
	 */
	public Integer getMaxItemsMobile() {
		return this.maxItemsMobile;
	}

	/**
	 * Get pagination desktop
	 * 
	 * @return Integer
	 */
	public Integer getPaginateDesktop() {
		return this.paginateDesktop;
	}

	/**
	 * Get pagination mobile
	 * 
	 * @return Integer
	 */
	public Integer getPaginateMobile() {
		return this.paginateMobile;
	}	

	/**
	 * Get exported type
	 * 
	 * @return String
	 */
	@Override
	public String getExportedType() {
		return this.request.getResource().getResourceType();
	}

	/**
	 * Is display header
	 * 
	 * @return true/false
	 */
	public boolean isDisplayHeader() {
		return this.displayHeader;
	}

	/**
	 * Get header option
	 * 
	 * @return Map
	 */
	public Map<String, Object> getHeaderOptions() {
		Map<String, Object> optionMap = new LinkedHashMap<>();
		if (this.displayHeader) {
			optionMap.put(SOIConstants.GROUP_BY, this.groupBy);
			optionMap.put(SOIConstants.HEADER_ELEMENT, 
					StringUtils.substringAfterLast(this.headerElement, SOIConstants.FW_SLASH));
			optionMap.put(SOIConstants.HEADER_STYLE, this.headerStyle);
			optionMap.put(SOIConstants.HEADER_SORTBY, this.headerSortOrder);
		}

		return optionMap;
	}

	/**
	 * Get column options
	 * 
	 * @return Map
	 */
	public Map<String, Object> getColumnOptions() {
		Map<String, Object> columnMap = new LinkedHashMap<>();
		if (this.columnsEnabled) {
			columnMap.put(SOIConstants.NUMBER_OF_COLUMNS, this.columns);
			if (this.paginateRow != null) {
				columnMap.put(SOIConstants.MAX_ROW_PAGINATION, this.paginateRow);
			}
			columnMap.put(SOIConstants.CONTENT_DIRECTION, this.contentDirection);
		}

		return columnMap;
	}

	/**
	 * Is link fragment provided
	 * 
	 * @return true/false
	 */
	public boolean isLinkFragment() {
		return this.linkFragment;
	}

	/**
	 * Get link options
	 * 
	 * @return Map
	 */
	public Map<String, Object> getLinkOptions() {
		Map<String, Object> linkMap = new LinkedHashMap<>();
		if (this.linkFragment) {
			linkMap.put(SOIConstants.LINK_FIELD, this.linkElementName);
			linkMap.put(SOIConstants.OPEN_TARGET_IN_NEW_TAB, this.linkTarget);
			linkMap.put(SOIConstants.LINK_EMAIL, this.linkEmail);
			linkMap.put(SOIConstants.LINK_PHONE_NUMBER, this.linkPhoneNumber);
		}

		return linkMap;
	}
}